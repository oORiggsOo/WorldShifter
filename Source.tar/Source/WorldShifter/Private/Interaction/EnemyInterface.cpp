// Copyright jB 2024/2025


#include "Interaction/EnemyInterface.h"

// Add default functionality here for any IEnemyInterface functions that are not pure virtual.
