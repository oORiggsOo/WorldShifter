// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PDGDRoomBase.generated.h"


class UArrowComponent;
class UBoxComponent;

UCLASS()
class WORLDSHIFTER_API APDGDRoomBase : public AActor
{
	GENERATED_BODY()

public:
	APDGDRoomBase();


	virtual void Tick(float DeltaTime) override;

protected:
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_1;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_2;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_3;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_4;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_5;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_6;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_7;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Wall_8;

	UPROPERTY(EditAnywhere, Category = "Components")
	UStaticMeshComponent* Floor;
	
	UPROPERTY(EditAnywhere, Category = "Components")
	UBoxComponent* BoxCollision;

	UPROPERTY(EditAnywhere, Category = "Components")
	UArrowComponent* Arrow;
};
