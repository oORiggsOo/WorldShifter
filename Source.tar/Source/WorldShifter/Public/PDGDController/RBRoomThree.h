// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "PDGDController/PDGDRoomBase.h"
#include "RBRoomThree.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API ARBRoomThree : public APDGDRoomBase
{
	GENERATED_BODY()
	
};
