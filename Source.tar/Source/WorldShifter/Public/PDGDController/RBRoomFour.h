// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "PDGDController/PDGDRoomBase.h"
#include "RBRoomFour.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API ARBRoomFour : public APDGDRoomBase
{
	GENERATED_BODY()
	
};
