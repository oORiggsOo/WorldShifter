// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "PDGDController/PDGDRoomBase.h"
#include "RBRoomOne.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API ARBRoomOne : public APDGDRoomBase
{
	GENERATED_BODY()
	
};
