// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "PDGDController/PDGDRoomBase.h"
#include "RBRoomFive.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API ARBRoomFive : public APDGDRoomBase
{
	GENERATED_BODY()
	
};
