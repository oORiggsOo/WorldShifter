// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "AbilitySystemComponent.h"
#include "ShifterAbilitySystemComponent.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API UShifterAbilitySystemComponent : public UAbilitySystemComponent
{
	GENERATED_BODY()
	
};
