// Copyright jB 2024/2025

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ShifterGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class WORLDSHIFTER_API AShifterGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
